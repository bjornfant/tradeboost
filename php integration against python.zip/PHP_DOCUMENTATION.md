# PHP Class Documentation for PreciousMetalsIdentifier

Complete guide for using the PHP class to identify precious metals products.

## Quick Start

```php
<?php
require_once 'PreciousMetalsIdentifier.php';

// Initialize
$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

// Identify a product
$result = $identifier->identifyProduct(
    'American Gold Eagle',           // name
    2000.00,                          // price
    'https://example.com/coin.jpg',  // image URL
    'USD'                             // currency (optional)
);

// Check result
if ($result !== false) {
    echo "Product: " . $result['identified_product'] . "\n";
    echo "Confidence: " . ($result['confidence_score'] * 100) . "%\n";
} else {
    echo "Error: " . $identifier->getLastError() . "\n";
}
?>
```

## Installation

1. **Copy the PHP class file** to your project:
   ```bash
   cp PreciousMetalsIdentifier.php /path/to/your/project/
   ```

2. **Ensure cURL is enabled** in PHP:
   ```bash
   # Check if cURL is installed
   php -m | grep curl
   
   # If not installed (Ubuntu/Debian):
   sudo apt-get install php-curl
   
   # Restart web server
   sudo systemctl restart apache2
   ```

3. **Include in your PHP file**:
   ```php
   require_once 'PreciousMetalsIdentifier.php';
   ```

## Class Reference

### Constructor

```php
__construct(string $apiUrl, int $timeout = 30)
```

**Parameters:**
- `$apiUrl` (string): Full URL to your CGI script
  - Example: `'http://yourserver.com/cgi-bin/precious_metals_cgi.py'`
- `$timeout` (int): Request timeout in seconds (default: 30)

**Example:**
```php
$identifier = new PreciousMetalsIdentifier(
    'http://example.com/cgi-bin/precious_metals_cgi.py',
    45  // 45 second timeout
);
```

---

### identifyProduct()

```php
identifyProduct(
    string $productName, 
    float $price, 
    string $imageUrl, 
    string $currency = 'USD'
): array|false
```

Identifies a single precious metals product.

**Parameters:**
- `$productName` (string): Name or description of the product
- `$price` (float): Price of the product (must be positive)
- `$imageUrl` (string): Public URL to the product image
- `$currency` (string): Currency code (default: 'USD')

**Returns:**
- `array` on success with keys:
  - `identified_product` (string): The identified product name
  - `confidence_score` (float): Confidence from 0.0 to 1.0
  - `confidence_percentage` (float): Confidence as percentage (0-100)
  - `metal_type` (string): 'gold', 'silver', 'platinum', or 'unknown'
  - `product_type` (string): 'coin', 'bar', 'round', or 'unknown'
  - `weight` (string|null): Weight/size of product
  - `manufacturer` (string|null): Manufacturer or mint name
  - `year` (string|null): Year of production
  - `reasoning` (string): Detailed explanation
  - `status` (string): 'success' or 'error'
- `false` on error (call `getLastError()` for details)

**Example:**
```php
$result = $identifier->identifyProduct(
    'American Gold Eagle 1 oz',
    2100.00,
    'https://example.com/gold-eagle.jpg',
    'USD'
);

if ($result !== false) {
    print_r($result);
} else {
    echo "Error: " . $identifier->getLastError();
}
```

---

### identifyBatch()

```php
identifyBatch(array $products): array|false
```

Identifies multiple products in a batch.

**Parameters:**
- `$products` (array): Array of product arrays, each containing:
  - `name` (string): Product name
  - `price` (float): Product price
  - `image_url` (string): Image URL
  - `currency` (string, optional): Currency code

**Returns:**
- `array` of results (one per product)
- `false` on validation error

**Example:**
```php
$products = [
    [
        'name' => 'Gold Eagle',
        'price' => 2000.00,
        'image_url' => 'https://example.com/coin1.jpg',
        'currency' => 'USD'
    ],
    [
        'name' => 'Silver Maple',
        'price' => 30.00,
        'image_url' => 'https://example.com/coin2.jpg'
    ]
];

$results = $identifier->identifyBatch($products);

foreach ($results as $result) {
    if ($result['status'] === 'success') {
        echo $result['identified_product'] . "\n";
    }
}
```

---

### getLastError()

```php
getLastError(): string|null
```

Gets the last error message.

**Returns:**
- `string`: Error message if an error occurred
- `null`: If no error

**Example:**
```php
$result = $identifier->identifyProduct(...);

if ($result === false) {
    $error = $identifier->getLastError();
    error_log("Identification failed: " . $error);
}
```

---

## Static Helper Methods

### isHighConfidence()

```php
PreciousMetalsIdentifier::isHighConfidence(array $result): bool
```

Checks if confidence is high (≥ 70%).

**Example:**
```php
if (PreciousMetalsIdentifier::isHighConfidence($result)) {
    echo "High confidence identification!";
}
```

---

### isMediumConfidence()

```php
PreciousMetalsIdentifier::isMediumConfidence(array $result): bool
```

Checks if confidence is medium (50-69%).

---

### isLowConfidence()

```php
PreciousMetalsIdentifier::isLowConfidence(array $result): bool
```

Checks if confidence is low (< 50%).

---

### formatSummary()

```php
PreciousMetalsIdentifier::formatSummary(array $result): string
```

Formats result as a simple string summary.

**Returns:** Formatted string like:
```
"American Gold Eagle 1 oz (Confidence: 92.5%) - Gold Coin - 1 oz"
```

**Example:**
```php
$summary = PreciousMetalsIdentifier::formatSummary($result);
echo $summary;
```

---

## Complete Usage Examples

### Example 1: Basic Product Identification

```php
<?php
require_once 'PreciousMetalsIdentifier.php';

$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

$result = $identifier->identifyProduct(
    'Canadian Gold Maple Leaf',
    2050.00,
    'https://example.com/maple.jpg'
);

if ($result !== false) {
    echo "Identified: {$result['identified_product']}\n";
    echo "Confidence: " . ($result['confidence_score'] * 100) . "%\n";
    echo "Metal: {$result['metal_type']}\n";
    echo "Type: {$result['product_type']}\n";
    
    if ($result['weight']) {
        echo "Weight: {$result['weight']}\n";
    }
    
    echo "\nReasoning:\n{$result['reasoning']}\n";
}
?>
```

### Example 2: Database Integration

```php
<?php
require_once 'PreciousMetalsIdentifier.php';

// Connect to database
$db = new PDO('mysql:host=localhost;dbname=inventory', 'user', 'pass');

// Initialize identifier
$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

// Get unidentified products
$stmt = $db->query("
    SELECT id, product_name, price, image_url 
    FROM products 
    WHERE identified_product IS NULL
    LIMIT 50
");

$products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Process each product
foreach ($products as $product) {
    $result = $identifier->identifyProduct(
        $product['product_name'],
        $product['price'],
        $product['image_url']
    );
    
    if ($result !== false) {
        // Update database
        $updateStmt = $db->prepare("
            UPDATE products 
            SET identified_product = :product,
                confidence_score = :confidence,
                metal_type = :metal,
                product_type = :type,
                weight = :weight,
                manufacturer = :manufacturer,
                year = :year,
                reasoning = :reasoning
            WHERE id = :id
        ");
        
        $updateStmt->execute([
            ':product' => $result['identified_product'],
            ':confidence' => $result['confidence_score'],
            ':metal' => $result['metal_type'],
            ':type' => $result['product_type'],
            ':weight' => $result['weight'],
            ':manufacturer' => $result['manufacturer'],
            ':year' => $result['year'],
            ':reasoning' => $result['reasoning'],
            ':id' => $product['id']
        ]);
        
        echo "✓ Identified product {$product['id']}\n";
    }
}
?>
```

### Example 3: API Endpoint

```php
<?php
/**
 * Create a REST API endpoint
 * File: api/identify.php
 */

require_once '../PreciousMetalsIdentifier.php';

header('Content-Type: application/json');

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate input
if (!isset($input['name'], $input['price'], $input['image_url'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing required fields']);
    exit;
}

// Initialize identifier
$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

// Identify product
$result = $identifier->identifyProduct(
    $input['name'],
    $input['price'],
    $input['image_url'],
    $input['currency'] ?? 'USD'
);

if ($result === false) {
    http_response_code(500);
    echo json_encode(['error' => $identifier->getLastError()]);
} else {
    echo json_encode($result);
}
?>
```

**Usage:**
```bash
curl -X POST http://yourserver.com/api/identify.php \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Gold Eagle",
    "price": 2000,
    "image_url": "https://example.com/coin.jpg",
    "currency": "USD"
  }'
```

### Example 4: Form Handler

```php
<?php
require_once 'PreciousMetalsIdentifier.php';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = new PreciousMetalsIdentifier(
        'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
    );
    
    $result = $identifier->identifyProduct(
        $_POST['product_name'],
        $_POST['price'],
        $_POST['image_url'],
        $_POST['currency'] ?? 'USD'
    );
    
    if ($result !== false) {
        // Success - display results
        ?>
        <div class="success">
            <h2>Identification Result</h2>
            <p><strong>Product:</strong> <?= htmlspecialchars($result['identified_product']) ?></p>
            <p><strong>Confidence:</strong> <?= number_format($result['confidence_score'] * 100, 1) ?>%</p>
            <p><strong>Metal:</strong> <?= htmlspecialchars($result['metal_type']) ?></p>
            <p><strong>Type:</strong> <?= htmlspecialchars($result['product_type']) ?></p>
            
            <?php if ($result['weight']): ?>
                <p><strong>Weight:</strong> <?= htmlspecialchars($result['weight']) ?></p>
            <?php endif; ?>
            
            <p><strong>Reasoning:</strong><br><?= nl2br(htmlspecialchars($result['reasoning'])) ?></p>
        </div>
        <?php
    } else {
        // Error
        echo '<div class="error">Error: ' . htmlspecialchars($identifier->getLastError()) . '</div>';
    }
}
?>

<!-- HTML Form -->
<form method="POST">
    <label>Product Name: <input type="text" name="product_name" required></label><br>
    <label>Price: <input type="number" step="0.01" name="price" required></label><br>
    <label>Currency: <input type="text" name="currency" value="USD" maxlength="3"></label><br>
    <label>Image URL: <input type="url" name="image_url" required></label><br>
    <button type="submit">Identify Product</button>
</form>
```

## Error Handling

Always check if the result is `false` and handle errors appropriately:

```php
$result = $identifier->identifyProduct(...);

if ($result === false) {
    $error = $identifier->getLastError();
    
    // Log the error
    error_log("Product identification failed: " . $error);
    
    // Show user-friendly message
    echo "Sorry, we couldn't identify this product. Please try again.";
    
    // Or throw an exception
    throw new Exception("Identification failed: " . $error);
}
```

## Common Errors

| Error Message | Cause | Solution |
|--------------|-------|----------|
| "Product name and image URL are required" | Missing parameters | Ensure all required fields are provided |
| "Price must be a positive number" | Invalid price | Check price is numeric and > 0 |
| "Invalid image URL" | Malformed URL | Validate URL format |
| "CURL Error: ..." | Network issue | Check network connectivity and URL |
| "HTTP Error: 500" | Server error | Check CGI script is working |
| "Could not parse response" | Invalid response | Check CGI script output |

## Performance Tips

1. **Use batch processing** for multiple products
2. **Implement caching** to avoid repeated API calls
3. **Set appropriate timeout** based on your needs
4. **Handle errors gracefully** to avoid breaking your application
5. **Monitor API usage** to stay within limits

## Security Considerations

1. **Validate all inputs** before passing to the API
2. **Sanitize output** when displaying to users (use `htmlspecialchars()`)
3. **Use HTTPS** for API endpoint if possible
4. **Don't expose API URLs** in client-side code
5. **Implement rate limiting** to prevent abuse
6. **Log errors** but don't expose internal details to users

## Requirements

- PHP 7.0 or higher
- cURL extension enabled
- Access to the CGI script endpoint
- Valid Gemini API key configured in CGI script

## Support

For issues or questions:
1. Check error messages with `getLastError()`
2. Verify CGI script is accessible
3. Test CGI script directly in browser
4. Check PHP error logs
5. Ensure cURL is enabled

## License

This PHP class is provided as example code for integration purposes.
