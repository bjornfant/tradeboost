<?php
/**
 * PreciousMetalsIdentifier - PHP Class
 * 
 * A PHP class to interact with the Gemini API-powered precious metals identifier
 * Sends product data (name, price, image URL) and receives identification results
 * 
 * @author  Your Name
 * @version 1.0
 */

class PreciousMetalsIdentifier {
    
    /**
     * @var string Base URL to the CGI script
     */
    private $apiUrl;
    
    /**
     * @var int Timeout in seconds for API requests
     */
    private $timeout;
    
    /**
     * @var string Last error message
     */
    private $lastError = null;
    
    /**
     * Constructor
     * 
     * @param string $apiUrl Full URL to the CGI script (e.g., http://yourserver.com/cgi-bin/precious_metals_cgi.py)
     * @param int $timeout Request timeout in seconds (default: 30)
     */
    public function __construct($apiUrl, $timeout = 30) {
        $this->apiUrl = rtrim($apiUrl, '/');
        $this->timeout = $timeout;
    }
    
    /**
     * Identify a single precious metals product
     * 
     * @param string $productName Name or description of the product
     * @param float $price Price of the product
     * @param string $imageUrl Public URL to the product image
     * @param string $currency Currency code (default: USD)
     * @return array|false Array with identification results, or false on error
     */
    public function identifyProduct($productName, $price, $imageUrl, $currency = 'USD') {
        // Validate inputs
        if (empty($productName) || empty($imageUrl)) {
            $this->lastError = "Product name and image URL are required";
            return false;
        }
        
        if (!is_numeric($price) || $price < 0) {
            $this->lastError = "Price must be a positive number";
            return false;
        }
        
        if (!filter_var($imageUrl, FILTER_VALIDATE_URL)) {
            $this->lastError = "Invalid image URL";
            return false;
        }
        
        // Prepare POST data
        $postData = [
            'product_name' => $productName,
            'price' => $price,
            'image_url' => $imageUrl,
            'currency' => $currency
        ];
        
        // Make HTTP request
        $response = $this->makeRequest($postData);
        
        if ($response === false) {
            return false;
        }
        
        // Parse HTML response to extract JSON result
        $result = $this->parseHtmlResponse($response);
        
        return $result;
    }
    
    /**
     * Identify multiple products in batch
     * 
     * @param array $products Array of products, each with keys: name, price, image_url, currency (optional)
     * @return array|false Array of identification results, or false on error
     * 
     * Example:
     * $products = [
     *     ['name' => 'Gold Eagle', 'price' => 2000, 'image_url' => 'http://...'],
     *     ['name' => 'Silver Maple', 'price' => 30, 'image_url' => 'http://...']
     * ];
     */
    public function identifyBatch($products) {
        if (empty($products) || !is_array($products)) {
            $this->lastError = "Products must be a non-empty array";
            return false;
        }
        
        $results = [];
        
        foreach ($products as $product) {
            $result = $this->identifyProduct(
                $product['name'] ?? '',
                $product['price'] ?? 0,
                $product['image_url'] ?? '',
                $product['currency'] ?? 'USD'
            );
            
            if ($result !== false) {
                $results[] = $result;
            } else {
                // Add error result
                $results[] = [
                    'input_name' => $product['name'] ?? '',
                    'status' => 'error',
                    'error_message' => $this->lastError,
                    'confidence_score' => 0
                ];
            }
        }
        
        return $results;
    }
    
    /**
     * Get the last error message
     * 
     * @return string|null Error message or null if no error
     */
    public function getLastError() {
        return $this->lastError;
    }
    
    /**
     * Make HTTP POST request to the API
     * 
     * @param array $postData POST data to send
     * @return string|false Response body or false on error
     */
    private function makeRequest($postData) {
        $ch = curl_init();
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $this->apiUrl,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($postData),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $this->timeout,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/x-www-form-urlencoded',
                'Accept: text/html,application/json'
            ]
        ]);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        if ($response === false) {
            $this->lastError = "CURL Error: " . $error;
            return false;
        }
        
        if ($httpCode !== 200) {
            $this->lastError = "HTTP Error: " . $httpCode;
            return false;
        }
        
        return $response;
    }
    
    /**
     * Parse HTML response to extract identification results
     * 
     * @param string $html HTML response from CGI script
     * @return array|false Parsed results or false on error
     */
    private function parseHtmlResponse($html) {
        // Try to find JSON in the response (if using batch API)
        if ($this->isJson($html)) {
            return json_decode($html, true);
        }
        
        // Parse HTML to extract results
        $result = [];
        
        // Extract identified product
        if (preg_match('/<strong style="font-size: 18px;">(.*?)<\/strong>/s', $html, $matches)) {
            $result['identified_product'] = trim(strip_tags($matches[1]));
        }
        
        // Extract confidence score
        if (preg_match('/<span class="confidence"[^>]*>([\d.]+)%<\/span>/s', $html, $matches)) {
            $result['confidence_score'] = floatval($matches[1]) / 100;
            $result['confidence_percentage'] = floatval($matches[1]);
        }
        
        // Extract metal type
        if (preg_match('/<span class="detail-label">Metal Type:<\/span>\s*(.*?)<\/div>/s', $html, $matches)) {
            $result['metal_type'] = strtolower(trim(strip_tags($matches[1])));
        }
        
        // Extract product type
        if (preg_match('/<span class="detail-label">Product Type:<\/span>\s*(.*?)<\/div>/s', $html, $matches)) {
            $result['product_type'] = strtolower(trim(strip_tags($matches[1])));
        }
        
        // Extract weight
        if (preg_match('/<span class="detail-label">Weight:<\/span>\s*(.*?)<\/div>/s', $html, $matches)) {
            $weight = trim(strip_tags($matches[1]));
            $result['weight'] = ($weight !== 'Not specified') ? $weight : null;
        }
        
        // Extract manufacturer
        if (preg_match('/<span class="detail-label">Manufacturer\/Mint:<\/span>\s*(.*?)<\/div>/s', $html, $matches)) {
            $manufacturer = trim(strip_tags($matches[1]));
            $result['manufacturer'] = ($manufacturer !== 'Not specified') ? $manufacturer : null;
        }
        
        // Extract year
        if (preg_match('/<span class="detail-label">Year:<\/span>\s*(.*?)<\/div>/s', $html, $matches)) {
            $year = trim(strip_tags($matches[1]));
            $result['year'] = ($year !== 'Not specified') ? $year : null;
        }
        
        // Extract reasoning
        if (preg_match('/<div class="reasoning">.*?<strong>Reasoning:<\/strong><br>\s*(.*?)<\/div>/s', $html, $matches)) {
            $result['reasoning'] = trim(strip_tags($matches[1]));
        }
        
        // Check if we found any results
        if (empty($result)) {
            // Check for error message
            if (preg_match('/<div class="error">.*?<strong>Error:<\/strong>\s*(.*?)<\/div>/s', $html, $matches)) {
                $this->lastError = trim(strip_tags($matches[1]));
                return false;
            }
            
            $this->lastError = "Could not parse response from API";
            return false;
        }
        
        $result['status'] = 'success';
        return $result;
    }
    
    /**
     * Check if string is valid JSON
     * 
     * @param string $string String to check
     * @return bool True if valid JSON
     */
    private function isJson($string) {
        json_decode($string);
        return json_last_error() === JSON_ERROR_NONE;
    }
    
    /**
     * Helper method to check if confidence is high (>= 70%)
     * 
     * @param array $result Result array from identifyProduct
     * @return bool True if confidence is high
     */
    public static function isHighConfidence($result) {
        return isset($result['confidence_score']) && $result['confidence_score'] >= 0.7;
    }
    
    /**
     * Helper method to check if confidence is medium (50-69%)
     * 
     * @param array $result Result array from identifyProduct
     * @return bool True if confidence is medium
     */
    public static function isMediumConfidence($result) {
        return isset($result['confidence_score']) 
            && $result['confidence_score'] >= 0.5 
            && $result['confidence_score'] < 0.7;
    }
    
    /**
     * Helper method to check if confidence is low (< 50%)
     * 
     * @param array $result Result array from identifyProduct
     * @return bool True if confidence is low
     */
    public static function isLowConfidence($result) {
        return isset($result['confidence_score']) && $result['confidence_score'] < 0.5;
    }
    
    /**
     * Format result as a simple string summary
     * 
     * @param array $result Result array from identifyProduct
     * @return string Formatted summary
     */
    public static function formatSummary($result) {
        if (!isset($result['identified_product'])) {
            return "Error: Unable to identify product";
        }
        
        $confidence = isset($result['confidence_percentage']) 
            ? number_format($result['confidence_percentage'], 1) 
            : number_format($result['confidence_score'] * 100, 1);
        
        $summary = $result['identified_product'] . " (Confidence: " . $confidence . "%)";
        
        if (isset($result['metal_type']) && isset($result['product_type'])) {
            $summary .= " - " . ucfirst($result['metal_type']) . " " . ucfirst($result['product_type']);
        }
        
        if (isset($result['weight'])) {
            $summary .= " - " . $result['weight'];
        }
        
        return $summary;
    }
}

?>
