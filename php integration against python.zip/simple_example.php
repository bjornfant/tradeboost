<?php
/**
 * SIMPLE EXAMPLE - Precious Metals Identifier
 * 
 * This is the simplest way to use the PreciousMetalsIdentifier class
 */

require_once 'PreciousMetalsIdentifier.php';

// =============================================================================
// STEP 1: Initialize the identifier
// =============================================================================

$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'  // Replace with your actual URL
);

// =============================================================================
// STEP 2: Identify a product
// =============================================================================

$result = $identifier->identifyProduct(
    'American Gold Eagle',           // Product name
    2000.00,                          // Price
    'https://example.com/coin.jpg',  // Image URL
    'USD'                             // Currency (optional)
);

// =============================================================================
// STEP 3: Check the result
// =============================================================================

if ($result !== false) {
    // Success! Display the results
    
    echo "Identified Product: " . $result['identified_product'] . "\n";
    echo "Confidence: " . ($result['confidence_score'] * 100) . "%\n";
    echo "Metal: " . $result['metal_type'] . "\n";
    echo "Type: " . $result['product_type'] . "\n";
    
    // Optional fields (may be null)
    if (!empty($result['weight'])) {
        echo "Weight: " . $result['weight'] . "\n";
    }
    
    if (!empty($result['manufacturer'])) {
        echo "Manufacturer: " . $result['manufacturer'] . "\n";
    }
    
    if (!empty($result['year'])) {
        echo "Year: " . $result['year'] . "\n";
    }
    
    echo "\nReasoning:\n" . $result['reasoning'] . "\n";
    
    // Check confidence level
    if (PreciousMetalsIdentifier::isHighConfidence($result)) {
        echo "\n✓ This is a HIGH confidence identification!\n";
    } elseif (PreciousMetalsIdentifier::isMediumConfidence($result)) {
        echo "\n⚠ This is a MEDIUM confidence identification.\n";
    } else {
        echo "\n✗ This is a LOW confidence identification.\n";
    }
    
} else {
    // Error occurred
    echo "Error: " . $identifier->getLastError() . "\n";
}

// =============================================================================
// ALTERNATIVE: Get a formatted summary
// =============================================================================

if ($result !== false) {
    echo "\nQuick Summary:\n";
    echo PreciousMetalsIdentifier::formatSummary($result) . "\n";
}

?>
