<?php
/**
 * Example Usage of PreciousMetalsIdentifier PHP Class
 * 
 * This file demonstrates how to use the PreciousMetalsIdentifier class
 * to identify precious metals products from your PHP application
 */

require_once 'PreciousMetalsIdentifier.php';

// =============================================================================
// EXAMPLE 1: Basic Usage - Single Product
// =============================================================================

echo "=== EXAMPLE 1: Identify Single Product ===\n\n";

// Initialize the identifier with your CGI script URL
$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

// Identify a product
$result = $identifier->identifyProduct(
    'American Gold Eagle',           // Product name
    2000.00,                          // Price
    'https://example.com/coin.jpg',  // Image URL
    'USD'                             // Currency (optional, defaults to USD)
);

// Check result
if ($result !== false) {
    echo "✓ Success!\n";
    echo "Identified Product: " . $result['identified_product'] . "\n";
    echo "Confidence: " . ($result['confidence_score'] * 100) . "%\n";
    echo "Metal Type: " . $result['metal_type'] . "\n";
    echo "Product Type: " . $result['product_type'] . "\n";
    
    if (isset($result['weight'])) {
        echo "Weight: " . $result['weight'] . "\n";
    }
    
    if (isset($result['manufacturer'])) {
        echo "Manufacturer: " . $result['manufacturer'] . "\n";
    }
    
    echo "\nReasoning: " . $result['reasoning'] . "\n";
} else {
    echo "✗ Error: " . $identifier->getLastError() . "\n";
}

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 2: Using Helper Methods
// =============================================================================

echo "=== EXAMPLE 2: Using Helper Methods ===\n\n";

$result = $identifier->identifyProduct(
    'Canadian Silver Maple Leaf',
    32.50,
    'https://example.com/silver-maple.jpg'
);

if ($result !== false) {
    // Check confidence level
    if (PreciousMetalsIdentifier::isHighConfidence($result)) {
        echo "✓ HIGH CONFIDENCE identification\n";
    } elseif (PreciousMetalsIdentifier::isMediumConfidence($result)) {
        echo "⚠ MEDIUM CONFIDENCE identification\n";
    } else {
        echo "✗ LOW CONFIDENCE identification\n";
    }
    
    // Get formatted summary
    echo PreciousMetalsIdentifier::formatSummary($result) . "\n";
}

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 3: Batch Processing
// =============================================================================

echo "=== EXAMPLE 3: Batch Processing ===\n\n";

$products = [
    [
        'name' => 'American Gold Eagle 1 oz',
        'price' => 2100.00,
        'image_url' => 'https://example.com/gold-eagle.jpg',
        'currency' => 'USD'
    ],
    [
        'name' => 'Canadian Silver Maple Leaf',
        'price' => 30.00,
        'image_url' => 'https://example.com/silver-maple.jpg',
        'currency' => 'USD'
    ],
    [
        'name' => 'PAMP Suisse Gold Bar',
        'price' => 5200.00,
        'image_url' => 'https://example.com/gold-bar.jpg'
    ]
];

$results = $identifier->identifyBatch($products);

foreach ($results as $index => $result) {
    echo "Product #" . ($index + 1) . ": ";
    
    if ($result['status'] === 'success') {
        echo $result['identified_product'];
        echo " (" . ($result['confidence_score'] * 100) . "% confident)\n";
    } else {
        echo "ERROR - " . $result['error_message'] . "\n";
    }
}

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 4: Database Integration
// =============================================================================

echo "=== EXAMPLE 4: Database Integration ===\n\n";

// Assume you have a database connection
// $db = new PDO('mysql:host=localhost;dbname=precious_metals', 'user', 'pass');

// Example: Get unidentified products from database
$sql = "SELECT id, product_name, price, image_url, currency 
        FROM products 
        WHERE identified_product IS NULL 
        LIMIT 10";

// $stmt = $db->query($sql);
// $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Simulate database results
$products = [
    [
        'id' => 1,
        'product_name' => 'Gold Coin Unknown',
        'price' => 1850.00,
        'image_url' => 'https://example.com/unknown-coin.jpg',
        'currency' => 'USD'
    ]
];

foreach ($products as $product) {
    echo "Processing product ID: " . $product['id'] . "\n";
    
    $result = $identifier->identifyProduct(
        $product['product_name'],
        $product['price'],
        $product['image_url'],
        $product['currency'] ?? 'USD'
    );
    
    if ($result !== false) {
        // Update database with results
        $updateSql = "UPDATE products 
                     SET identified_product = ?,
                         confidence_score = ?,
                         metal_type = ?,
                         product_type = ?,
                         weight = ?,
                         manufacturer = ?,
                         year = ?,
                         reasoning = ?,
                         identified_at = NOW()
                     WHERE id = ?";
        
        // $stmt = $db->prepare($updateSql);
        // $stmt->execute([
        //     $result['identified_product'],
        //     $result['confidence_score'],
        //     $result['metal_type'],
        //     $result['product_type'],
        //     $result['weight'],
        //     $result['manufacturer'],
        //     $result['year'],
        //     $result['reasoning'],
        //     $product['id']
        // ]);
        
        echo "  ✓ Identified as: " . $result['identified_product'] . "\n";
        echo "  ✓ Saved to database\n";
    } else {
        echo "  ✗ Error: " . $identifier->getLastError() . "\n";
    }
}

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 5: Error Handling
// =============================================================================

echo "=== EXAMPLE 5: Error Handling ===\n\n";

// Invalid URL
$result = $identifier->identifyProduct(
    'Test Product',
    100.00,
    'not-a-valid-url'
);

if ($result === false) {
    echo "Error caught: " . $identifier->getLastError() . "\n";
}

// Invalid price
$result = $identifier->identifyProduct(
    'Test Product',
    -50.00,  // Negative price
    'https://example.com/image.jpg'
);

if ($result === false) {
    echo "Error caught: " . $identifier->getLastError() . "\n";
}

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 6: WordPress Integration Example
// =============================================================================

echo "=== EXAMPLE 6: WordPress Integration ===\n\n";

/**
 * WordPress shortcode example
 * Add this to your theme's functions.php
 */
function precious_metals_identify_shortcode($atts) {
    $atts = shortcode_atts([
        'name' => '',
        'price' => 0,
        'image_url' => '',
        'currency' => 'USD'
    ], $atts);
    
    $identifier = new PreciousMetalsIdentifier(
        get_option('precious_metals_api_url')
    );
    
    $result = $identifier->identifyProduct(
        $atts['name'],
        $atts['price'],
        $atts['image_url'],
        $atts['currency']
    );
    
    if ($result === false) {
        return '<div class="error">Error: ' . $identifier->getLastError() . '</div>';
    }
    
    $output = '<div class="precious-metal-result">';
    $output .= '<h3>' . esc_html($result['identified_product']) . '</h3>';
    $output .= '<p>Confidence: <strong>' . ($result['confidence_score'] * 100) . '%</strong></p>';
    $output .= '<p>' . esc_html($result['reasoning']) . '</p>';
    $output .= '</div>';
    
    return $output;
}
// add_shortcode('identify_precious_metal', 'precious_metals_identify_shortcode');

echo "WordPress integration example (see code comments)\n";

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 7: REST API Wrapper
// =============================================================================

echo "=== EXAMPLE 7: REST API Wrapper ===\n\n";

/**
 * Create a REST API endpoint for your application
 */
function handleApiRequest() {
    header('Content-Type: application/json');
    
    // Get POST data
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (!$input || !isset($input['name'], $input['price'], $input['image_url'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Missing required fields']);
        return;
    }
    
    $identifier = new PreciousMetalsIdentifier(
        'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
    );
    
    $result = $identifier->identifyProduct(
        $input['name'],
        $input['price'],
        $input['image_url'],
        $input['currency'] ?? 'USD'
    );
    
    if ($result === false) {
        http_response_code(500);
        echo json_encode(['error' => $identifier->getLastError()]);
        return;
    }
    
    echo json_encode($result);
}

// Example: if ($_SERVER['REQUEST_URI'] === '/api/identify') {
//     handleApiRequest();
// }

echo "REST API wrapper example (see code comments)\n";

echo "\n" . str_repeat("=", 70) . "\n\n";

// =============================================================================
// EXAMPLE 8: Caching Results
// =============================================================================

echo "=== EXAMPLE 8: Caching Results ===\n\n";

/**
 * Cache results to reduce API calls
 */
function identifyWithCache($identifier, $name, $price, $imageUrl, $currency = 'USD') {
    // Create cache key
    $cacheKey = 'pm_' . md5($name . $price . $imageUrl);
    
    // Try to get from cache (example using file cache)
    $cacheFile = sys_get_temp_dir() . '/' . $cacheKey . '.cache';
    
    if (file_exists($cacheFile)) {
        $cacheData = json_decode(file_get_contents($cacheFile), true);
        
        // Check if cache is less than 24 hours old
        if (time() - $cacheData['timestamp'] < 86400) {
            echo "✓ Retrieved from cache\n";
            return $cacheData['result'];
        }
    }
    
    // Not in cache or expired, fetch from API
    $result = $identifier->identifyProduct($name, $price, $imageUrl, $currency);
    
    if ($result !== false) {
        // Save to cache
        file_put_contents($cacheFile, json_encode([
            'timestamp' => time(),
            'result' => $result
        ]));
        echo "✓ Fetched from API and cached\n";
    }
    
    return $result;
}

$identifier = new PreciousMetalsIdentifier(
    'http://yourserver.com/cgi-bin/precious_metals_cgi.py'
);

$result = identifyWithCache(
    $identifier,
    'Gold Eagle',
    2000.00,
    'https://example.com/coin.jpg'
);

echo "\n" . str_repeat("=", 70) . "\n\n";

?>
